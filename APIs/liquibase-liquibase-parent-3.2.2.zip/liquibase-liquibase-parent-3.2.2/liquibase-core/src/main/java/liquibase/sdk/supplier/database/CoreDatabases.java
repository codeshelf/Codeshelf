package liquibase.sdk.supplier.database;

public class CoreDatabases {
}
