package liquibase.command;

public class CommandExecutionException extends Exception {
    public CommandExecutionException(Throwable cause) {
        super(cause);
    }
}
