package liquibase.logging;

public enum LogLevel {
    DEBUG, INFO, WARNING, SEVERE, OFF;

}
