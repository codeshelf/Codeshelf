package liquibase.parser;

public interface LiquibaseParser {
}
