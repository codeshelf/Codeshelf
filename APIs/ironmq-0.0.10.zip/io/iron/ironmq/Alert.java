package io.iron.ironmq;

public class Alert {
    String type;
    String direction;
    int trigger;
    int snooze;
    String queue;
    String id;
}
