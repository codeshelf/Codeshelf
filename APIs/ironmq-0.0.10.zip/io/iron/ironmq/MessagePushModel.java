package io.iron.ironmq;

public class MessagePushModel {
    int retries_delay;
    int retries_remaining;
    int status_code;
    String status;
    String url;
    String id;
}
