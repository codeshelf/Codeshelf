package com.example.pojo.auction;

public class Persistent {
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long long1) {
        id = long1;
    }

}
