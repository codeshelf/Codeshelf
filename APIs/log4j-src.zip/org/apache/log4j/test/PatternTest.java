/*
 * Copyright 1999-2005 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.log4j.test;

import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.LogManager;
import org.apache.log4j.Priority;
/**
   This class is a test of the PatternLayout class.

   @author Ceki G&uuml;lc&uuml;
*/
public class PatternTest {
  static Logger CAT = Logger.getLogger(PatternTest.class);


  public 
  static 
  void main(String argv[]) {

    if(argv.length == 1) 
      init(argv[0]);
    else 
      Usage("Wrong number of arguments.");

    test();
  }

  static
  void Usage(String msg) {
    System.err.println(msg);
    System.err.println( "Usage: java " + PatternTest.class.getName() +
			" configFile");
    System.exit(1);
  }
  static
  void init(String configFile) {
    PropertyConfigurator.configure(configFile);
  }

  static
  void test() {
    int i = -1;
    Logger root = Logger.getRootLogger();
    
    CAT.debug("Message " + ++i);
    root.debug("Message " + i);        

    CAT.info ("Message " + ++i);
    root.info("Message " + i);        

    CAT.warn ("Message " + ++i);
    root.warn("Message " + i);        

    CAT.error("Message " + ++i);
    root.error("Message " + i);
    
    CAT.log(Priority.FATAL, "Message " + ++i);
    root.log(Priority.FATAL, "Message " + i);    
    
    Exception e = new Exception("Just testing");
    CAT.debug("Message " + ++i, e);
    root.debug("Message " + i, e);
    
    CAT.info("Message " + ++i, e);
    root.info("Message " + i, e);    

    CAT.warn("Message " + ++i , e);
    root.warn("Message " + i , e);    

    CAT.error("Message " + ++i, e);
    root.error("Message " + i, e);    

    CAT.log(Priority.FATAL, "Message " + ++i, e);
    root.log(Priority.FATAL, "Message " + i, e);    
    
    LogManager.shutdown();
  }
}
