package org.java_websocket.exceptions;

public class WebsocketNotConnectedException extends RuntimeException {
	private static final long serialVersionUID = 2387838980084049791L;

}
