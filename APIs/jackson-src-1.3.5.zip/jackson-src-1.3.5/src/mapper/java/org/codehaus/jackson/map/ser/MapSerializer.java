package org.codehaus.jackson.map.ser;

/**
 * Replacement for {@link ContainerSerializers#MapSerializer}.
 *
 * @since 1.3.5
 */
public class MapSerializer
    extends ContainerSerializers.MapSerializer
{
    public MapSerializer() { super(); }
}
