/**
 * Annotations that directly depend on Mapper classes and are used
 * for configuring Data Mapping functionality.
 */
package org.codehaus.jackson.map.annotate;
