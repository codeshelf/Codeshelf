/**
 * Concrete {@link org.codehaus.jackson.type.JavaType} implementations.
 */
package org.codehaus.jackson.map.type;
