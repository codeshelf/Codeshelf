/**
 * Jackson-based JAX-RS provider that can automatically
 * serialize and deserialize resources for 
 * JSON content type (MediaType).
 */
package org.codehaus.jackson.jaxrs;
